const express = require('express');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const generateVCF = require('./generateVCF');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const CONTACT_FILE = 'contacts.json';

app.post('/api/contact', (req, res) => {
  const { name, phone } = req.body;
  const contacts = fs.existsSync(CONTACT_FILE) ? JSON.parse(fs.readFileSync(CONTACT_FILE)) : [];
  contacts.push({ name, phone });
  fs.writeFileSync(CONTACT_FILE, JSON.stringify(contacts, null, 2));
  res.sendStatus(200);
});

app.get('/admin/download', (req, res) => {
  const contacts = fs.existsSync(CONTACT_FILE) ? JSON.parse(fs.readFileSync(CONTACT_FILE)) : [];
  const vcfData = generateVCF(contacts);
  res.setHeader('Content-disposition', 'attachment; filename=ibking-contacts.vcf');
  res.setHeader('Content-Type', 'text/vcard');
  res.send(vcfData);
});

app.listen(PORT, () => console.log(`IBKing server running on http://localhost:${PORT}`));
