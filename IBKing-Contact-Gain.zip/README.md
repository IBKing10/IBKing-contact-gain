# IBKing Contact Gain 🔥

Villain-themed WhatsApp contact gain site.

## How to Run
1. Install dependencies:
   ```
   npm install
   ```

2. Start the server:
   ```
   npm start
   ```

3. Visit: http://localhost:3000

## Admin
Download contacts as `.vcf`:
- Go to: `http://localhost:3000/admin/download`
