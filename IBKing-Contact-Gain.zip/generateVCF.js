module.exports = function generateVCF(contacts) {
  return contacts.map(({ name, phone }) => (
    `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL;TYPE=CELL:${phone}\nEND:VCARD`
  )).join('\n');
};
